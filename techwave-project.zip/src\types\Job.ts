export interface Job {
  id?: string;
  titulo: string;
  local: string;
  descricao: string;
}
